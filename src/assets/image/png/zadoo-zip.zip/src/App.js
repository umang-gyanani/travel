import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import Destination from "./components/Destination";
import Book from "./components/Book";

function App() {
  return (
    <>
      <Destination />
      <Book />
    </>
  );
}

export default App;
